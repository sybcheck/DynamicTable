package site.duanzy.pdf.pojo;

public class contract {
    private int seq;
    private String sampleName;
    private String batchNum;
    private String standard;
    private String sampleAmout;
    private String batch;
    private String sampleNum;
    private String testType;
    private String sampleInf;

    public int getSeq() {
        return seq;
    }

    public void setSeq(int seq) {
        this.seq = seq;
    }

    public String getSampleName() {
        return sampleName;
    }

    public void setSampleName(String sampleName) {
        this.sampleName = sampleName;
    }

    public String getBatchNum() {
        return batchNum;
    }

    public void setBatchNum(String batchNum) {
        this.batchNum = batchNum;
    }

    public String getStandard() {
        return standard;
    }

    public void setStandard(String standard) {
        this.standard = standard;
    }

    public String getSampleAmout() {
        return sampleAmout;
    }

    public void setSampleAmout(String sampleAmout) {
        this.sampleAmout = sampleAmout;
    }

    public String getBatch() {
        return batch;
    }

    public void setBatch(String batch) {
        this.batch = batch;
    }

    public String getSampleNum() {
        return sampleNum;
    }

    public void setSampleNum(String sampleNum) {
        this.sampleNum = sampleNum;
    }

    public String getTestType() {
        return testType;
    }

    public void setTestType(String testType) {
        this.testType = testType;
    }

    public String getSampleInf() {
        return sampleInf;
    }

    public void setSampleInf(String sampleInf) {
        this.sampleInf = sampleInf;
    }
}
